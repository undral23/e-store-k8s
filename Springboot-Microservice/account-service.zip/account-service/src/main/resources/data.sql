INSERT INTO account (id, username, last_name, email, shipping_address, password) VALUES
(1, 'user1', 'lastname1', 'email1@gmail.com', 'shipping addr1', '$2a$10$slYQmyNdGzTn7ZLBXBChFOC9f6kFjAqPhccnP6DxlWXx2lPk1C3G6'),
(2, 'user2', 'lastname2', 'email2@gmail.com', 'shipping addr2', '$2a$10$slYQmyNdGzTn7ZLBXBChFOC9f6kFjAqPhccnP6DxlWXx2lPk1C3G6');
